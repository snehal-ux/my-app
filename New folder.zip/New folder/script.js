// document.addEventListener('DOMContentLoaded', () => {
//     const boxes = document.querySelectorAll('.box');
//     let activeBox = null;

//     // Initialize color buttons
//     document.querySelectorAll('.color-btn').forEach(btn => {
//         btn.style.backgroundColor = btn.dataset.color;
//     });

//     // Box click handler
//     boxes.forEach(box => {
//         box.addEventListener('click', (e) => {
//             // Prevent click event from bubbling up
//             e.stopPropagation();

//             // If clicking the same box, close it
//             if (activeBox === box) {
//                 box.classList.remove('expanded');
//                 activeBox = null;
//                 return;
//             }

//             // Close previously active box
//             if (activeBox) {
//                 activeBox.classList.remove('expanded');
//             }

//             // Open clicked box
//             box.classList.add('expanded');
//             activeBox = box;
//         });
//     });

//     // Color button click handler
//     document.querySelectorAll('.color-btn').forEach(btn => {
//         btn.addEventListener('click', (e) => {
//             e.stopPropagation();
//             const box = btn.closest('.box');
//             const color = btn.dataset.color;
//             box.style.backgroundColor = color;
//         });
//     });

//     // Size button click handler
//     document.querySelectorAll('.size-btn').forEach(btn => {
//         btn.addEventListener('click', (e) => {
//             e.stopPropagation();
//             const box = btn.closest('.box');
//             const size = btn.dataset.size;
            
//             // Remove active class from all size buttons in this box
//             box.querySelectorAll('.size-btn').forEach(b => b.classList.remove('active'));
            
//             // Add active class to clicked button
//             btn.classList.add('active');

//             // Apply size changes
//             switch(size) {
//                 case 'small':
//                     box.style.height = '150px';
//                     break;
//                 case 'medium':
//                     box.style.height = '250px';
//                     break;
//                 case 'large':
//                     box.style.height = '350px';
//                     break;
//             }
//         });
//     });

//     // Close box when clicking outside
//     document.addEventListener('click', () => {
//         if (activeBox) {
//             activeBox.classList.remove('expanded');
//             activeBox = null;
//         }
//     });
// }); 


document.addEventListener('DOMContentLoaded', () => {
    const boxes = document.querySelectorAll('.box');
    let activeBox = null;
  
    boxes.forEach(box => {
      box.addEventListener('click', e => {
        e.stopPropagation();
  
        // Collapse previously active
        if (activeBox && activeBox !== box) {
          activeBox.classList.remove('expanded');
        }
  
        // Toggle current
        box.classList.toggle('expanded');
        activeBox = box.classList.contains('expanded') ? box : null;
  
        // Select radio input
        const radio = box.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;
      });
    });
  
    document.addEventListener('click', (e) => {
        const isClickInsideBox = e.target.closest('.box');
    
        // If the click was outside the activeBox, close it
        if (activeBox && !isClickInsideBox) {
            activeBox.classList.remove('expanded');
            activeBox = null;
        }
    });
    
  });
  